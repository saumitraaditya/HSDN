#!/bin/bash
nohup python /namingSupport/dnschef.py --fakeip 127.0.0.1 --socialAccount /namingSupport/dns-config.json -q &
